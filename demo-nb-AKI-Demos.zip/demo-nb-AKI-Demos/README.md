### Beispiel-Notebook zur Programmierung mit Python
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fhswf/aki-notebooks/HEAD?filepath=Python101.ipynb)

### Beispiel-Notebook zum Gradientenverfahren
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fhswf/aki-notebooks/HEAD?filepath=Demo-AKI-GD.ipynb)


### Beispiel-Notebook zur Logistischen Regression
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fhswf/aki-notebooks/HEAD?filepath=Demo-AKI-LogReg.ipynb)
